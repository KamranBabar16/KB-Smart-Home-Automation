![App Screenshot](/examples/GettingStarted/BlynkBlink/App.png)

You can setup a copy of this project easily by scanning this QR code:
![App ](/examples/GettingStarted/BlynkBlink/AppQR.png)
